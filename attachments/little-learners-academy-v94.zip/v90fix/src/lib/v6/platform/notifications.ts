/** V6 platform module: platform/notifications. */

export type NotificationsId = string;

export interface NotificationsRecord {
  id: NotificationsId;
  createdAt: number;
  updatedAt: number;
  version: number;
}

export function createNotificationsId(prefix = "notifications"): NotificationsId {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

export function isNotificationsRecord(value: unknown): value is NotificationsRecord {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return typeof v.id === "string" && typeof v.createdAt === "number" && typeof v.updatedAt === "number" && typeof v.version === "number";
}
